import React, { Component } from 'react';
import Button from "./html/Button";
import Container from './html/Container';
import Text from './html/Text';


class App extends Component {
  constructor(props) {
    super(props);
    // You don't have any specific constructor logic here.
  }

  state = {
    buttonText: "Button",
    containerClassName: "container-fluid",
    textValue: "It is test",
    textTitle: "Title"
  }

  handleClick = () => {
    console.log("Button clicked");
  };

  render() {
    return (
      <Container className={this.state.containerClassName}>
        <Text title={this.state.textTitle}>{this.state.textValue}</Text>
        <Button onClick={this.handleClick}>
          {this.state.buttonText}
        </Button>
      </Container>
    );
  }
}

export default App;
