// MainLayout.jsx
import React from 'react';

const MainLayout = ({ children }) => (
  <div style={{ border: '1px solid black', padding: '10px' }}>
    <header>
      <h1>Todo App</h1>
    </header>
    <main>{children}</main>
    <footer>Footer</footer>
  </div>
);

export default MainLayout;
