// index.js
import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import MainLayout from '../../html/templates/MainLayout';
import TodoPage from './templates/TodoPage';

const App = () => {
  const [todos, setTodos] = useState([]);

  const addTodo = (todo) => {
    setTodos([...todos, todo]);
  };

  const removeTodo = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  return (
    <MainLayout>
      <TodoPage todos={todos} addTodo={addTodo} removeTodo={removeTodo} />
    </MainLayout>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
