// TodoPage.jsx
import React from 'react';
import TodoList from '../components/TodoList';
import TodoForm from '../components/TodoForm';

const TodoPage = ({ todos, addTodo, removeTodo }) => (
  <div>
    <TodoForm addTodo={addTodo} />
    <TodoList todos={todos} removeTodo={removeTodo} />
  </div>
);

export default TodoPage;
