// TodoItem.jsx
import React from 'react';
import Button from '../../../html/components/Button';

const TodoItem = ({ todo, removeTodo }) => (
  <li>
    {todo.text}
    <Button onClick={() => removeTodo(todo.id)} text="Remove" />
  </li>
);

export default TodoItem;
