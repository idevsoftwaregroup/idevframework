// TodoForm.jsx
import React, { useState } from 'react';
import Input from '../../../html/components/Input';
import Button from '../../../html/components/Button';

const TodoForm = ({ addTodo }) => {
  const [text, setText] = useState('');

  const handleInputChange = (e) => {
    setText(e.target.value);
  };

  const handleSubmit = () => {
    if (text.trim() !== '') {
      addTodo({
        id: Date.now(),
        text,
      });
      setText('');
    }
  };

  return (
    <div>
      <Input type="text" placeholder="Enter your todo" value={text} onChange={handleInputChange} />
      <Button onClick={handleSubmit} text="Add Todo" />
    </div>
  );
};

export default TodoForm;
