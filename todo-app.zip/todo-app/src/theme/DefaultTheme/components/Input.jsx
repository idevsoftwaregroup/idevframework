// Input.jsx
import React from 'react';

const Input = ({ type, placeholder, value, onChange }) => (
  <input
    style={{ border: '1px solid blue', padding: '5px', borderRadius: '3px' }}
    type={type}
    placeholder={placeholder}
    value={value}
    onChange={onChange}
  />
);

export default Input;
