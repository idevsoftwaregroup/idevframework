// Button.jsx
import React from 'react';

const Button = ({ onClick, text }) => (
  <button style={{ backgroundColor: 'blue', color: 'white' }} onClick={onClick}>
    {text}
  </button>
);

export default Button;
