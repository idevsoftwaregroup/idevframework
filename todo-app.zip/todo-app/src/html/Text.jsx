// Text.jsx
import React from 'react';

const Text = ({ title, children }) => {
  return (
    <>
      <p title={title}>{children}</p>
    </>
  );
}

export default Text;
